## TRY THIS ON linux.student.cs 

1) run server : python server.py 5000 10 
2) client : python client.py 127.0.0.1 5000 10 'this is the string to be reversed'

